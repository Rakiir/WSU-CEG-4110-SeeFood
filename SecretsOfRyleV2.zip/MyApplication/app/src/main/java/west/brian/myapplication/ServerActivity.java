package west.brian.myapplication;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ServerActivity extends AppCompatActivity {
    private int index;
    private int numPics;
    public srobject2 sro = new srobject2();
    public Context c;
    private ImageView imView;
    private TextView stat1Tv, stat2Tv, resultTv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sro = (srobject2) getIntent().getSerializableExtra("sro");
        setContentView(R.layout.activity_server);
        index = 0;
        stat1Tv = (TextView) findViewById(R.id.stat1);
        stat2Tv = (TextView) findViewById(R.id.stat2);
        resultTv = (TextView) findViewById(R.id.resultView);
        imView =  (ImageView) findViewById(R.id.imageView);
        sro.requestFileAmount();
        numPics = sro.getFileAmount();
        sro.getPic("0");
        while(!sro.getPicGotten()){}
        sro.setPicGotten(false);
        Bitmap bmap = sro.getImage();
        imView.setImageBitmap(bmap);
        String temp = sro.getReceivedFilePath();

        String array[] = temp.split("XX");
        stat1Tv.setText(array[0]);
        stat2Tv.setText(array[1]);
    }

    public void Back(View v){
       startActivity(new Intent(ServerActivity.this, MainActivity.class));
    }

    public void Previous(View v){

        if (index == 0){
            index = numPics-1;
        }else{
            index--;
        }
        String temp1 = Integer.toString(index);
        sro.getPic(temp1);
        while(!sro.getPicGotten()){}
        sro.setPicGotten(false);
        Bitmap bmap = sro.getImage();
        imView.setImageBitmap(bmap);
        String temp = sro.getReceivedFilePath();
        String array[] = temp.split("XX");
        stat1Tv.setText(array[0]);
        stat2Tv.setText(array[1]);
    }

    public void Next(View v){

        if(index == numPics-1){
            index = 0;
        }else{
            index++;
        }
        String temp1 = Integer.toString(index);
        sro.getPic(temp1);
        while(!sro.getPicGotten()){}
        sro.setPicGotten(false);
        Bitmap bmap = sro.getImage();
        imView.setImageBitmap(bmap);
        String temp = sro.getReceivedFilePath();

        String array[] = temp.split("XX");
        stat1Tv.setText(array[0]);
        stat2Tv.setText(array[1]);




    }

    public String computeResult(double stat1, double stat2) {
        String[] posArray = {
                "I swear by my forge, this food will be safe to eat, traveller.",
                "Prepared by the finest elves of Houose Telvanni, this will be a marvelous meal!",
                "This meal must have been made by magiccraft it is so divine!" };
        String[] negArray = {
                "Wherever there are elves, there are lies.  This here reeks of elvish trickery!",
                "Man cerig?!  That'll kill you young one!",
                "Whoever told you to eat this can go kiss an orc!",
                "I... you really want to eat it?  Well, you can certainly try..."};

        double confidence = Math.abs(stat1 - stat2);
        if (confidence <= 0.5) {
            return "It seems I've failed my perception check, I could not tell you if this is food or not.";
        } else {
            if (stat1 > stat2) {
                int random = (int) (Math.random() * (posArray.length - 1));
                return posArray[random];
            } else {
                int random = (int) (Math.random() * (negArray.length - 1));
                return negArray[random];
            }
        }
    }  //end computeResult method

}
