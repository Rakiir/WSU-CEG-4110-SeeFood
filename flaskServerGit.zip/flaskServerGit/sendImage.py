import requests
url = 'http://3.16.170.151:5000/upload'
files = {'media': open('gun.jpg', 'rb')}
response = requests.post(url, files=files)
print(response.text)
