import requests
from PIL import Image
import shutil
#from io import StringIO
url = 'http://3.16.170.151:5000/getphoto'
payload = {'type': '0'}
response = requests.get(url, params=payload, stream = True)
with open('img.jpg', 'wb') as out_file:
    shutil.copyfileobj(response.raw, out_file)
del response
#response.content
#i = Image.open(StringIO(response.content))
#i.save('i.jpg')