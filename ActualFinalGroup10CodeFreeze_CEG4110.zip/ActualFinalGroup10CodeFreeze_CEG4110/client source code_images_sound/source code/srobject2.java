package west.brian.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.Vector;
import okhttp3.Call;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.Callback;
import okhttp3.ResponseBody;

/**srobject2
 * @author Dylan Dunham
 * This class is designed to send photos back and forth between the android application and the aws EC2 flask server seefood AI. It holds a queue of strings that are the
 * paths to photos stored locally that need to be processed and sends them sequentially each time sendPic is called. Also retrieves photos stored on the server. All server tasks
 * are async!
 */
public class srobject2 implements Serializable {
    private String fileString;//String to file to send to server
    private Vector<String> sendStrings = new Vector<String>();
    private String receivedString;//string of file processed
    private String urlUpload; //https://xxx.xxx.xxx.xxx:5000/upload
    private String urlGetImage; //https://xxx.xxx.xxx.xxx:5000/getpic
    private String urlGetImageName; //https://xxx.xxx.xxx.xxx:5000/getpicname
    private boolean picGotten = false;
    private int fileAmount;
    private String urlFileAmount; //https://xxx.xxx.xxx.xxx:5000/getFileAmount
    private String receivedFilePath;//filepath of photo from online gallery
    private Bitmap image;

    /**Constructor
     *
     */
    public srobject2() { }

    public boolean getPicGotten() {
        return picGotten;
    }
    public void setPicGotten(boolean picGotten) {
        this.picGotten = picGotten;
    }
    public void enqueue(String s){
        sendStrings.add(s);
    }
    public void empty(){
        sendStrings.clear();
    }
    public void setUrlFileAmount(String urlFileAmount) {
        this.urlFileAmount = urlFileAmount;
    }
    public int getFileAmount() {
        return fileAmount;
    }
    public Bitmap getImage() {
        return image;
    }
    public String getReceivedString() { return receivedString; }
    public void setReceivedStringToNull(){
        receivedString= null;
    }
    public boolean isQueueEmpty(){
        return sendStrings.isEmpty();
    }
    public String getUrlGetImageName() {
        return urlGetImageName;
    }
    public void setUrlGetImageName(String urlGetImageName) {this.urlGetImageName = urlGetImageName; }
    public String getFileString() {
        return fileString;
    }
    public String getReceivedFilePath() {
        return receivedFilePath;
    }
    public void setURLUpload(String URL) {
        urlUpload = URL;
    }
    public String getURLUpload() {
        return urlUpload;
    }
    public void setURLGetImage(String URL) {
        urlGetImage = URL;
    }
    public String getURLGetImage() {
        return urlGetImage;
    }

    /**requestFileAmount
     * Function sets fileAmount variable of srobject2 to the value returned by the server.
     * @param: none
     * @return: none
     *
     */
    public void requestFileAmount(){
        final OkHttpClient client = new OkHttpClient();
        Request request1 = new Request.Builder()
                .url(urlFileAmount)
                .build();
        client.newCall(request1).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override public void onResponse(Call call, Response response1) throws IOException {
                try (ResponseBody responseBody = response1.body()) {
                    if (!response1.isSuccessful()) throw new IOException("Unexpected code " + response1);
                    Headers responseHeaders = response1.headers();
                    for (int i = 0, size = responseHeaders.size(); i < size; i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }
                    String temp = responseBody.string();
                    fileAmount = Integer.parseInt(temp);
                }
            }
        });
    }
    /**sendPic
     * Function sends photo of .jpg or .png type located at fileString directory. Sets fileString to first string in queue before sending. Sets receivedString to results from server.
     * @param: none
     * @return: none
     *
     */
    public void sendPic() {

        final OkHttpClient client = new OkHttpClient();
        fileString = sendStrings.remove(0);
        if(fileString!=null) {


            String split[] = fileString.split("\\.");
            String fileExtension = split[1];
            if (fileExtension.equals("png")) {
                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("media", "image.png",
                                RequestBody.create(MediaType.parse("image/png"), new File(fileString)))
                        .build();

                Request request = new Request.Builder()
                        .url(urlUpload)
                        .post(requestBody)
                        .build();
                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        try (ResponseBody responseBody = response.body()) {
                            if (!response.isSuccessful())
                                throw new IOException("Unexpected code " + response);
                            receivedString = responseBody.string();
                        }
                    }
                });
            } else {
                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("media", "image.jpg",
                                RequestBody.create(MediaType.parse("image/jpg"), new File(fileString)))
                        .build();

                Request request = new Request.Builder()
                        .url(urlUpload)
                        .post(requestBody)
                        .build();
                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        try (ResponseBody responseBody = response.body()) {
                            if (!response.isSuccessful())
                                throw new IOException("Unexpected code " + response);
                            receivedString = responseBody.string();
                        }
                    }
                });
            }
        }
    }
    /**getPic
     * Function sends request to server for photo at X position in server directory, X being an integer but as a string. will set image to response from server.
     * @param: typeParameter
     * @return: none
     *
     */
    public void getPic(String typeParameter) {
        String url = HttpUrl.parse(urlGetImageName).newBuilder()
                .addQueryParameter("type", typeParameter)
                .build().toString();
        final OkHttpClient client = new OkHttpClient();
        Request request1 = new Request.Builder()
                .url(url)
                .build();
        client.newCall(request1).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override public void onResponse(Call call, Response response1) throws IOException {
                try (ResponseBody responseBody = response1.body()) {
                    if (!response1.isSuccessful()) throw new IOException("Unexpected code " + response1);
                    receivedFilePath = responseBody.string();
                }
            }
        });
        String url2 = HttpUrl.parse(urlGetImage).newBuilder()
                .addQueryParameter("type", typeParameter)
                .build().toString();
        Request request2 = new Request.Builder()
                .url(url2)
                .build();
        Response response2 = null;
        client.newCall(request2).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override public void onResponse(Call call, Response response2) throws IOException {
                try (ResponseBody responseBody = response2.body()) {
                    if (!response2.isSuccessful()) throw new IOException("Unexpected code " + response2);
                    image = BitmapFactory.decodeStream(response2.body().byteStream());
                    picGotten = true;
                }
            }
        });
    }
}