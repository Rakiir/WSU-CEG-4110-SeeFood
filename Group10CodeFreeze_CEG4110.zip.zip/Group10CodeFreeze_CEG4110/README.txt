Group 10: Dylan Dunham, Thomas Caltabellotta, and Brian West
Secrets of Rlyeh
To review the ec2 flask server code go to "server source code", and the script is there.
To review the android application's source code go to "client source code_images_sound" -> "source code" and all the java files will be there.
To review the android application's UI elements go to "client source code_images_sound" -> "images for UI" and all the images for the UI are there.
To review the android application's sound elements go to "client source code_images_sound" -> "sound" and all the sounds for the application are there.

github link: https://github.com/Rakiir/WSU-CEG-4110-SeeFood

