public class JavaSRObj {
}
