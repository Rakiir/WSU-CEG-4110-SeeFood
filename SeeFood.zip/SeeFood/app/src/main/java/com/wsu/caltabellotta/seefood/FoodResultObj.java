package com.wsu.caltabellotta.seefood;

public class FoodResultObj {

}
