package com.wsu.caltabellotta.seefood;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class StartViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_view);
    }
}
